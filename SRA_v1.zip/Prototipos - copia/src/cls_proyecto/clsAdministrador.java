/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cls_proyecto;

/**
 *
 * @author lauso
 */
public class clsAdministrador {
     //variables
    private String usuario;
    private String contraseña;
    
    //constructor
    public clsAdministrador() {
        this.usuario="admin1309";
        this.contraseña = "alohomora";
    }
    
    //getter y setter
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    //Metodos
    
    public int verificarContraseña (String passw){
        int verificacion=0;
        if(this.contraseña.equals(passw)){
            verificacion=1;
        }
        return verificacion;
    }
    
    public int verificarUsuario (String us){
        int verificacion=0;
        if(this.usuario.equalsIgnoreCase(us)){
            verificacion=1;
        }
        return verificacion;
    }
}
